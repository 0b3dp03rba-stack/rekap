"use client";

import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const res = await signIn("credentials", {
      username,
      password,
      redirect: false,
    });
    setLoading(false);
    if (res?.error) {
      setError("Username atau password salah.");
    } else {
      router.push("/");
      router.refresh();
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="glint-border w-[380px] max-w-full">
        <div className="card p-9">
          <div className="flex items-center gap-3 mb-1">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-aura to-[#5b3fae] flex items-center justify-center shadow-[0_0_18px_rgba(155,107,255,0.5)]">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M6 3H18L22 9L12 21L2 9L6 3Z" stroke="white" strokeWidth="1.6" strokeLinejoin="round" />
              </svg>
            </div>
            <h1 className="text-[19px] font-display font-semibold">Aura Store</h1>
          </div>
          <p className="text-[13px] text-muted mb-7">Masuk untuk mengelola rekap keuangan</p>

          {error && (
            <div className="bg-[#3a1f26] border border-[rgba(255,107,107,0.35)] text-[#ffb3b3] text-[13px] px-3 py-2.5 rounded-lg mb-4">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="username">Username</label>
              <input
                id="username"
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="owner"
              />
            </div>
            <div>
              <label htmlFor="password">Password</label>
              <input
                id="password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
              />
            </div>
            <button type="submit" disabled={loading} className="btn-primary w-full mt-2">
              {loading ? "Memproses..." : "Masuk"}
            </button>
          </form>

          <div className="mt-5 p-3 rounded-lg bg-panel2 border border-dashed border-border text-[12px] text-muted leading-relaxed">
            Login pertama kali: <b className="text-white">owner</b> / <b className="text-white">aurastore123</b>
            <br />Segera ganti password lewat halaman Pengguna setelah masuk.
          </div>
        </div>
      </div>
    </div>
  );
}
